<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2013 color-rain.ru

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.',
    'readme' => 'TinyUrl for MODx Revolution
=================================
**Author: Evgeniy Kalyada (http://www.color-rain.ru)**

A snippet for automatically generate short url.

Installation
============
Simply download through Package Management, and install.

Use this constructions into chunk or templates: 
[[tinyurl?&url=`[[++site_url]][[~[[*id]]]]`]]
[[tinyurl?&url=`http://www.lognlink.com`]]

Documentation
=============
Please see the official documentation at:
http://color-rain.ru/modx-tinyurl',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '7a2a13b660287d497ab7ee37fad3778f',
      'native_key' => 'tinyurl',
      'filename' => 'modNamespace/096466e5b012ccbd37329543c179a218.vehicle',
      'namespace' => 'tinyurl',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'c9478cec9393ced7c3a9656e3c51a7f4',
      'native_key' => 1,
      'filename' => 'modCategory/e0e2dabe8288787837c833c2c487af67.vehicle',
      'namespace' => 'tinyurl',
    ),
  ),
);